import React, {useState, useEffect} from "react";
import {
    Box,
    Button,
    Grid,
    Typography,
    Paper,
    Radio,
    RadioGroup,
    FormControlLabel,
    TextField,
    CircularProgress,
    Snackbar,
    Alert,
} from "@mui/material";
import {getData} from "@/helpers/functions/getData";
import {handleRequestSubmit} from "@/helpers/functions/handleSubmit";
import {useToastContext} from "@/providers/ToastLoadingProvider";
import dayjs from "dayjs";

const AssignmentAnswers = ({dayAttendanceId, isEdit = false, userAssignmentId, setData, onClose}) => {
    const [questions, setQuestions] = useState([]);
    const [questionAnswers, setQuestionAnswers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [alertOpen, setAlertOpen] = useState(false);
    const [alertMessage, setAlertMessage] = useState("");
    const {setLoading: setSubmitLoading} = useToastContext();
    const [userTotalRating, setUserTotalRating] = useState(0);
    const [lastRatingDate, setLastRatingDate] = useState("");
    const [assignment, setAssignment] = useState();
    useEffect(() => {
        const fetchAssignmentData = async () => {
            try {
                setLoading(true);
                const extraParam = isEdit ? "?isArchive=true&" : ""
                // Fetch assignment questions
                const assignmentRequest = await getData({
                    url: `center/attendance/${dayAttendanceId}/assignments${extraParam}`,
                    setLoading,
                });

                const assignmentQuestions = assignmentRequest.data;
                setAssignment(assignmentRequest.data);
                setLastRatingDate(assignmentRequest.data.lastRatingDate && dayjs(assignmentRequest.data.lastRatingDate).format("DD-MM-YYYY"));
                setUserTotalRating(assignmentRequest.data.totalRating);
                let formattedAnswers = [];
                if (isEdit && userAssignmentId) {
                    const userAssignmentRequest = await getData({
                        url: `center/assignments/${userAssignmentId}`,
                        setLoading,
                    });
                    const userAssignmentAnswers = userAssignmentRequest.data.questionAnswers;

                    formattedAnswers = assignmentQuestions.questions.map((question) => {
                        const matchedAnswer = userAssignmentAnswers.find((answer) => answer.questionId === question.id);
                        return matchedAnswer
                              ? {
                                  questionId: question.id,
                                  selectedChoice: matchedAnswer.choice,
                                  comment: matchedAnswer.comment || "",
                                  questionPoint: question.totalPoints,
                                  choicePoints: matchedAnswer.choice.points,
                              }
                              : {
                                  questionId: question.id,
                                  selectedChoice: null,
                                  comment: "",
                                  questionPoint: question.totalPoints,
                                  choicePoints: 0,
                              };
                    });
                } else {
                    formattedAnswers = assignmentQuestions.questions.map((question) => ({
                        questionId: question.id,
                        selectedChoice: null,
                        comment: "",
                        questionPoint: question.totalPoints,
                        choicePoints: 0,
                    }));
                }

                setQuestions(assignmentQuestions.questions);
                setQuestionAnswers(formattedAnswers);
            } catch (error) {
                console.error("Error fetching assignment data", error);
            } finally {
                setLoading(false);
            }
        };

        fetchAssignmentData();
    }, [dayAttendanceId, isEdit, userAssignmentId]);

    const handleChoiceChange = (questionIndex, choice) => {
        const newAnswers = [...questionAnswers];
        newAnswers[questionIndex].selectedChoice = choice;
        newAnswers[questionIndex].choicePoints = choice.points;
        setQuestionAnswers(newAnswers);
    };

    const handleCommentChange = (questionIndex, comment) => {
        const newAnswers = [...questionAnswers];
        newAnswers[questionIndex].comment = comment;
        setQuestionAnswers(newAnswers);
    };

    const calculateTotals = () => {
        let totalRating = 0;
        let totalScore = 0;
        questionAnswers.forEach((answer) => {
            totalRating += answer.questionPoint;
            totalScore += answer.choicePoints;
        });

        return {totalRating, totalScore};
    };

    const handleSubmit = async () => {
        const {totalRating, totalScore} = calculateTotals();

        try {
            const data = {
                dayAttendanceId,
                questionAnswers: questionAnswers.map((answer) => ({
                    questionId: answer.questionId,
                    choiceId: answer.selectedChoice?.id,
                    comment: answer.comment,
                    questionPoint: answer.questionPoint,
                    choicePoints: answer.choicePoints,
                })),
                userTotalRating,
                totalRating,
                totalScore,
                userId: assignment.userId,
            };
            const request = await handleRequestSubmit(
                  data,
                  setSubmitLoading,
                  isEdit ? `center/assignments/${userAssignmentId}` : `center/attendance/${dayAttendanceId}/assignments`,
                  false,
                  "جاري الحفظ",
                  null,
                  isEdit ? "PUT" : "POST"
            );
            if (request.status === 200) {
                if (!isEdit) {
                    if (setData) {
                        setData((items) =>
                              items.map((item) => {
                                  if (item.id === dayAttendanceId) {
                                      item.userAssignment = request.data;
                                  }
                                  return item;
                              })
                        );
                    }
                }
                onClose();
            }
        } catch (error) {
            console.error(error);
            setAlertMessage("Error saving assignment");
            setAlertOpen(true);
        }
    };

    const handleAlertClose = () => {
        setAlertOpen(false);
    };

    if (loading) {
        return (
              <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
                  <CircularProgress/>
              </Box>
        );
    }
    if (!assignment) return <Alert severity="info">No assigment for this duty</Alert>
    const totalAssigmentRating = calculateTotals().totalRating
    return (
          <Box sx={{maxWidth: "800px", margin: "auto", mt: 4}}>
              <Typography variant="h5" gutterBottom>
                  {assignment?.title}
              </Typography>
              <Typography variant="h6">
                  Assigment score {totalAssigmentRating}
              </Typography>
              <Typography>
                  Current Score :{calculateTotals().totalScore}
              </Typography>
              {questions.map((question, index) => (
                    <Paper key={question.id} sx={{padding: 3, marginTop: 2}}>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Typography variant="h6" sx={{fontWeight: 'bold'}}>
                                    Question {index + 1}: {question.title}
                                </Typography>
                            </Grid>

                            <Grid item xs={12}>
                                <RadioGroup
                                      value={questionAnswers[index].selectedChoice ? questionAnswers[index].selectedChoice.id : null}
                                      onChange={(e) =>
                                            handleChoiceChange(
                                                  index,
                                                  question.choices.find((choice) => choice.id === parseInt(e.target.value))
                                            )
                                      }
                                >
                                    {question.choices.map((choice) => (
                                          <FormControlLabel
                                                key={choice.id}
                                                value={choice.id}
                                                control={<Radio/>}
                                                label={`${choice.text} (Points: ${choice.points})`}
                                                sx={{marginBottom: 1}}
                                          />
                                    ))}
                                </RadioGroup>
                            </Grid>

                            <Grid item xs={12}>
                                <TextField
                                      label="Comment (Optional)"
                                      fullWidth
                                      multiline
                                      rows={3}
                                      value={questionAnswers[index].comment}
                                      onChange={(e) => handleCommentChange(index, e.target.value)}
                                      sx={{marginTop: 2}}
                                />
                            </Grid>
                        </Grid>
                    </Paper>
              ))}

              <Typography variant="h6" color="textSecondary" sx={{marginTop: 4}}>
                  This next section is the total rating of all user attendances, not just this one.
              </Typography>

              <Typography variant="body2" sx={{marginTop: 2}}>
                  Last Rating Date: {lastRatingDate || "N/A"}
              </Typography>

              {/* Total Rating (Editable) */}
              <TextField
                    label="Total Rating"
                    variant="outlined"
                    fullWidth
                    type="number"
                    margin="normal"
                    value={userTotalRating || ""}
                    onChange={(e) => setUserTotalRating(e.target.value)}
              />

              <Button variant="contained" color="primary" onClick={handleSubmit} sx={{marginTop: 4}}>
                  Save Assignment
              </Button>

              <Snackbar open={alertOpen} autoHideDuration={4000} onClose={handleAlertClose}>
                  <Alert onClose={handleAlertClose} severity="success" sx={{width: "100%"}}>
                      {alertMessage}
                  </Alert>
              </Snackbar>
          </Box>
    );
};

export default AssignmentAnswers;
