"use client"
import MultiStepForm from "@/app/UiComponents/FormComponents/Forms/MultiStepForm";

export default function Register(){
    return (
          <div className={"py-20 w-full bg-bgPrimary"}>

          <MultiStepForm/>
          </div>
    )
}